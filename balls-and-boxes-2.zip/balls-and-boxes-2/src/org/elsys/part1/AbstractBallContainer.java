package org.elsys.part1;

public abstract class AbstractBallContainer {

}
