package org.elsys.part1;

public class NotEnoughCapacityException extends RuntimeException {

}
