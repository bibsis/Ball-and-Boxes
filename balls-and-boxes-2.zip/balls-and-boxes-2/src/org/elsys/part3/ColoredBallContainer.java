package org.elsys.part3;

import org.elsys.part1.Color;

public class ColoredBallContainer {

	public ColoredBallContainer(Color color) {
		
	}

	public Color getColor() {
		return null;
	}
}
